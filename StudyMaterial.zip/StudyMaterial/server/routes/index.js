const express = require('express');
const mysql = require('mysql');

const pool = mysql.createPool({

    connectionLimit:10,
    password:'',
    user:'root',
    database:'studymaterial',
    host:'localhost',
    port:'3308'

});

const router = express.Router();

router.get('/', async (req, res, next) => {
    try{
        let results = await new Promise((resolve, reject) => {
        pool.query(`SELECT * FROM tbluser`, (err, result) =>{
            if(err){
                return reject(err);
            }
            return resolve(result);
    
            });
        });
        res.json(results);
    } catch(e){
        console.log(e);
        res.sendStatus(500);
    }
});

router.get('/:id', async (req, res) => {
    try{
        const id = req.params.id;
        let results = await new Promise((resolve, reject) => {
        pool.query(`SELECT * FROM tbluser where Userid=?`,[id], (err, result) =>{
            if(err){
                return reject(err);
            }
            return resolve(result);
    
            });
        });
        res.json(results);
    } catch(e){
        console.log(e);
        res.sendStatus(500);
    }
});

router.post('/UserLogin/', async (req, res) => {
    try{
        const { email,  password} = req.body;
        const queryData = [ email,  password];
        let results = await new Promise((resolve, reject) => {
        pool.query(`SELECT UserId, Name, EmailId, ContactNo FROM tbluser WHERE IsActive =1 AND  EmailId=? AND Password=?`,queryData, (err, result) =>{
            if(err){
                return reject(err);
            }
            return resolve(result);
    
            });
        });
        res.json(results);
    } catch(e){
        console.log(e);
        res.sendStatus(500);
    }
});

router.post('/UserReg/', async (req, res) => {
    try{
        const {name, email, contact, password, createdby} = req.body;
        const queryData = [name, email, contact, password, createdby, 1];
        let results = await new Promise((resolve, reject) => {
        pool.query(`INSERT INTO tbluser( Name, EmailId, ContactNo, Password,  CreatedBy, IsActive) VALUES (?,?,?,?,?,?)`,queryData, (err, result) =>{
            if(err){
                return reject(err);
            }
            return resolve(result);
    
            });
        });
        res.json(results);
    } catch(e){
        console.log(e);
        res.sendStatus(500);
    }
});

router.put('/userUpdate/:id', async (req, res) => {
    try{
        const id= req.params.id;
        var datetime = new Date();
        const {name, email, contact, password} = req.body;
        const queryData = [name, email, contact, password, datetime,  1, id];
        let results = await new Promise((resolve, reject) => {
        pool.query(`UPDATE tbluser SET Name=?, EmailId=?, ContactNo=?, Password=?, ModifyDate=?, ModifyBy=? WHERE UserId= ?`,queryData, (err, result) =>{
            if(err){
                return reject(err);
            }
            return resolve(result);
    
            });
        });
        res.json(results);
    } catch(e){
        console.log(e);
        res.sendStatus(500);
    }
});

router.post('/addStudyMat/', async (req, res) => {
    try{
        const {name, description, time, fileid, createdby} = req.body;
        const queryData = [name, description, time, fileid, createdby, 1];
        let results = await new Promise((resolve, reject) => {
        pool.query(`INSERT INTO tblstudymaterial(Name, Description, Time, FileId, CreatedBy,IsActive)  VALUES (?,?,?,?,?,?)`,queryData, (err, result) =>{
            if(err){
                return reject(err);
            }
            return resolve(result);
    
            });
        });
        res.json(results);
    } catch(e){
        console.log(e);
        res.sendStatus(500);
    }
});


router.post('/addFile/', async (req, res) => {
    try{
        const {filename, path, size, extension, createdby} = req.body;
        const queryData = [filename, path, size, extension, createdby, 1];
        let results = await new Promise((resolve, reject) => {
        pool.query(`INSERT INTO tblfile( FileName, Path, Size, Extension, CreatedBy, IsActive)   VALUES (?,?,?,?,?,?)`,queryData, (err, result) =>{
            if(err){
                return reject(err);
            }
            return resolve(result);
    
            });
        });
        res.json(results);
    } catch(e){
        console.log(e);
        res.sendStatus(500);
    }
});

router.post('/userSMAccess/', async (req, res) => {
    try{
        const {userid, studymatId, time, iscom, createdby} = req.body;
        const queryData = [userid, studymatId, time, iscom, createdby, 1];
        let results = await new Promise((resolve, reject) => {
        pool.query(`INSERT INTO tbluserstudymaterial( UserId, StudyMaterialId, Time, IsComplete,  CreatedBy, IsActive)    VALUES (?,?,?,?,?,?)`,queryData, (err, result) =>{
            if(err){
                return reject(err);
            }
            return resolve(result);
    
            });
        });
        res.json(results);
    } catch(e){
        console.log(e);
        res.sendStatus(500);
    }
});

router.put('/userSMUpdateTime/:id', async (req, res) => {
    try{
        const id= req.params.id;
        var datetime = new Date();
        const {time, iscom, modifyby} = req.body;
        const queryData = [time, iscom, modifyby, password, datetime,  1, id];
        let results = await new Promise((resolve, reject) => {
        pool.query(`UPDATE tbluserstudymaterial SET Time=?, IsComplete=?,ModifyDate=?,ModifyBy=? WHERE UserStudyMaterialId=?`,queryData, (err, result) =>{
            if(err){
                return reject(err);
            }
            return resolve(result);
    
            });
        });
        res.json(results);
    } catch(e){
        console.log(e);
        res.sendStatus(500);
    }
});

module.exports=router;