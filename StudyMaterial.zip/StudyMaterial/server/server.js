const express = require('express');
const apiRouter = require('./routes');
const cors = require("cors");

const app = express();

app.use(express.json());

app.use(cors());

app.use('/api/study', apiRouter);

app.listen(process.env.POT || '3000', () => {

    console.log(`Servver is runiing port: ${process.env.PORT || '3000'}`);

});